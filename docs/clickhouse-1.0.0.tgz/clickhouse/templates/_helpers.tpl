{{/*
Expand the name of the chart.
*/}}
{{- define "clickhouse-cluster.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "clickhouse-cluster.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "clickhouse-cluster.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "clickhouse-cluster.labels" -}}
helm.sh/chart: {{ include "clickhouse-cluster.chart" . }}
{{ include "clickhouse-cluster.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "clickhouse-cluster.selectorLabels" -}}
app.kubernetes.io/name: {{ include "clickhouse-cluster.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Recursively render nested settings as key/value pairs
Usage: {{ include "clickhouse-cluster.renderSettings" (dict "settings" .Values.keeper.settings "prefix" "") }}
*/}}
{{- define "clickhouse-cluster.renderSettings" -}}
{{- $settings := .settings }}
{{- $prefix := .prefix }}
{{- range $key, $value := $settings }}
{{- if kindIs "map" $value }}
{{- $newPrefix := ternary (printf "%s/%s" $prefix $key) $key (ne $prefix "") }}
{{- include "clickhouse-cluster.renderSettings" (dict "settings" $value "prefix" $newPrefix) }}
{{- else }}
{{- $fullKey := ternary (printf "%s/%s" $prefix $key) $key (ne $prefix "") }}
{{ $fullKey }}: {{ $value | quote }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Render profiles section
Usage: {{ include "clickhouse-cluster.renderProfiles" .Values.clickhouse.profiles }}
*/}}
{{- define "clickhouse-cluster.renderProfiles" -}}
{{- range $profile, $settings := . }}
{{- range $key, $value := $settings }}
{{ $profile }}/{{ $key }}: {{ $value }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Render quotas section
Usage: {{ include "clickhouse-cluster.renderQuotas" .Values.clickhouse.quotas }}
*/}}
{{- define "clickhouse-cluster.renderQuotas" -}}
{{- range $quota, $settings := . }}
{{- range $section, $values := $settings }}
{{- range $key, $value := $values }}
{{ $quota }}/{{ $section }}/{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{- define "clickhouse-cluster.renderUserNode" }}
{{- $prefix := .prefix }}
{{- $value := .value }}

{{- if kindIs "map" $value }}
{{- range $key, $subValue := $value }}
{{- include "clickhouse-cluster.renderUserNode" (dict "prefix" (printf "%s/%s" $prefix $key) "value" $subValue) }}
{{- end }}

{{- else if kindIs "slice" $value }}
{{ printf "%s:" $prefix }}
{{ toYaml $value }}

{{- else }}
{{ printf "%s: %q" $prefix (toString $value) }}

{{- end }}
{{- end }}

{{/*
Render users section
Usage: {{ include "clickhouse-cluster.renderUsers" .Values.clickhouse.users }}
*/}}
{{- define "clickhouse-cluster.renderUsers" -}}
{{- range $user, $settings := . }}
{{- include "clickhouse-cluster.renderUserNode" (dict "prefix" $user "value" $settings) }}
{{- end }}
{{- end }}

{{/*
Render user settings recursively
*/}}
{{- define "clickhouse-cluster.renderUserSettings" -}}
{{- $user := .user }}
{{- $settings := .settings }}
{{- range $key, $value := $settings }}
{{- if kindIs "map" $value }}
{{- range $subKey, $subValue := $value }}
{{ $user }}/{{ $key }}/{{ $subKey }}: {{ $subValue | quote }}
{{- end }}
{{- else }}
{{ $user }}/{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Generate all ClickHouse services for schema restore (all shards and replicas)
*/}}
{{- define "clickhouse-cluster.schemaRestoreServices" -}}
{{- $clusterName := .Values.clusterName }}
{{- $shardsCount := .Values.clickhouse.shardsCount }}
{{- $replicasCount := .Values.clickhouse.replicasCount }}
{{- $services := list }}
{{- range $shard := until (int $shardsCount) }}
  {{- range $replica := until (int $replicasCount) }}
    {{- $serviceName := printf "chi-%s-clickhouse-%d-%d" $clusterName $shard $replica }}
    {{- $services = append $services $serviceName }}
  {{- end }}
{{- end }}
{{- join "," $services }}
{{- end }}

{{/*
Generate ClickHouse services for data backup/restore (only first replica of each shard)
*/}}
{{- define "clickhouse-cluster.clickhouseServices" -}}
{{- $clusterName := .Values.clusterName }}
{{- $shardsCount := .Values.clickhouse.shardsCount }}
{{- $dataServices := list }}
{{- range $shard := until (int $shardsCount) }}
  {{- $serviceName := printf "chi-%s-clickhouse-%d-0" $clusterName $shard }}
  {{- $dataServices = append $dataServices $serviceName }}
{{- end }}
{{- join "," $dataServices }}
{{- end }}
